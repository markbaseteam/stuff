---

kanban-plugin: basic

---

## TODO



## DOING



## DONE





%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%