- Type unions
- Discriminated type union means give a literal type identifier to an interface.
- Index types: [key]: string is an object of named instances 
- ?? Is for checking against null or undefined only
- checks for object property. Same as object.hasownprop
```js
"x" in y 
```
-  

