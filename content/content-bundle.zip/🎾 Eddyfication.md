      

- Breathe in for rhythm
- Recover early and stay stable so I don’t have the rush
- Keep head locked and stable
- Racket path under the ball
- Focus on contact 
- Keep chest down

