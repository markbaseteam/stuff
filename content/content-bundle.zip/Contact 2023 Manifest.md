# CONTACT 2023 Manifest

## FIXME
- [ ] VENUE PAGE
	- [ ]  Kill Programs on archives
	- [ ]  Possibly add more fine grained filtering for past shows
- [ ]  Archived Shows, unify URLS
- [ ]  Fix URLS on search results
- [ ]  Remove Map on archived venues, or remove festival pins on archived venue map.
- [ ]  Simplify Tags


## TODO

- [ ]  Add Videos to ehixbition pages
- [ ]  Use theme tags on frontend (aka interest)
- [ ]  ACCESSIBILITY
	- [ ]  Add correct [ARIA](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA) markup
- [ ]  SEO
	- [ ]  JSON-LD markup for events (so we get listed in google searches for arts events etc.)
	- [ ]  Better Keywords
	- [ ]  Proper Sitemap
	- [ ]  Open Graph markup for facebook and twitter embeds


## Design
- [ ] Homepage. Rethink . More Dynamic. More Useful. Get across the activity of festival instead of a single cover image.
- [ ] Mobile Ergonomics 
	- [ ] Tabs on Exhibition Pages ( Exhibition / Location / Audio?)
	- [ ] Shows in modal overlays, swipe to next show.
	- [ ] Expanded sheets for filters etc.
- [ ]  Conversations Page
- [ ]  Calendar Filters Globally ( today, tomorrow, this weekend, this week, specific day ) So that the filter can ba applide to any listing page (listing, calendar, map)

## Infrastructure Stuff (optional nice to have stuff)
- [ ] Headless setup
- [ ] Containerise wordpress and Move to Google Cloud Platform ? (2 years for free)
- [ ] MIgrate from ACF to CMB2
- [ ] Move images from AWS to cloudflare R2 

## Contingency Planning
- [ ] Create website documentation. All passwords and accounts etc.

